/*
============================================
; Title: 1.4 - TypeScript
; Author: Professor Krasso
; Date: 12/18/20
; Modified by:Wendy Leon
; Description: TypeScript
;==========================================
*/

//public person module
export interface IPerson{
    firstName: string;
    lastName: string;
}